document.addEventListener('DOMContentLoaded', function () {
    const formulario = document.getElementById('formularioIngreso');
    
    formulario.addEventListener('submit', function(event) {
        
        event.preventDefault();

       
        const nombre = document.getElementById('txtNombre').value;
        const apellido = document.getElementById('txtApellido').value;
        const numero = document.getElementById('txtNumero').value;
        const email = document.getElementById('mail').value;

        
        if (!nombre || !apellido || !numero || !email) {
            alert("Por favor, complete todos los campos.");
            return;
        }

        
        const mail = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (!mail.test(mail)) {
            alert("Por favor, ingresa un correo electrónico válido.");
            return;
        }

        
        if (numero.length < 10) {
            alert("El número telefónico debe tener al menos 10 dígitos.");
            return;
        }

        
        const resultado = window.confirm("¿Estás seguro de que deseas enviar el formulario?");
        if (resultado) {
            alert("Formulario enviado correctamente.");
            formulario.submit(); 
        } else {
            alert("Formulario no enviado.");
        }
    });
});